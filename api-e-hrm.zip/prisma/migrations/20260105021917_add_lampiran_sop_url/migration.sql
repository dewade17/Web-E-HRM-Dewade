-- AlterTable
ALTER TABLE `sop_karyawan` ADD COLUMN `lampiran_sop_url` LONGTEXT NULL;
