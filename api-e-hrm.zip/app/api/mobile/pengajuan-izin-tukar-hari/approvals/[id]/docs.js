/**
 * @swagger
 * /api/mobile/pengajuan-izin-tukar-hari/approvals/{id}:
 *   put:
 *     summary: Beri keputusan approval tukar hari
 *     description: Mengambil keputusan menyetujui atau menolak pada level approval tertentu.
 *     tags: [Mobile - Pengajuan Izin Tukar Hari]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [decision]
 *             properties:
 *               decision:
 *                 type: string
 *                 enum: [disetujui, ditolak]
 *               note:
 *                 type: string
 *                 nullable: true
 *               id_pola_kerja_pengganti:
 *                 type: string
 *                 nullable: true
 *     responses:
 *       '200':
 *         description: Keputusan berhasil disimpan dan status pengajuan diperbarui bila memenuhi level approval.
 *       '400':
 *         description: Body keputusan tidak valid.
 *       '401':
 *         description: Tidak terautentikasi.
 *       '403':
 *         description: Pengguna tidak memiliki akses untuk approval ini.
 *       '404':
 *         description: Approval atau pengajuan tidak ditemukan.
 *       '409':
 *         description: Approval sudah memiliki keputusan atau status pengajuan tidak sesuai.
 */
