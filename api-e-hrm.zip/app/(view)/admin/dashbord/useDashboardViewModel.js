export default function useDashboardViewModel() {
    
    return {};
}